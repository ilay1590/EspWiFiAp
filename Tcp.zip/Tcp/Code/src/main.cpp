#include <boost/asio.hpp>
#include <iostream>
#include <thread>
#include <chrono>
#include "TcpServer.h" // Include your TcpServer header file
#include "TcpConnection.h"

void my_data_handler(const std::string& data, const boost::system::error_code& ec) {
    if (!ec) {
        std::cout << "Received data: " << data << std::endl;
    } else {
        std::cerr << "Error: " << ec.message() << std::endl;
    }
}

int main() {
    boost::asio::io_context io_context;
    boost::asio::io_context io_context2;

    // // Create a TcpServer on port 12345
    TcpServer server(io_context, 12345);

    // Set a data handler function
    server.set_data_handler([](const std::string& data, const boost::asio::ip::tcp::endpoint& endpoint) {
        std::cout << "Received data from " << endpoint.address().to_string() 
                    << ": " << data << std::endl;

        // Optional: Respond to the client if needed (example, echo)
        // You could pass the socket to the callback for this purpose.
    });

    // Start the server
    server.start();
    // Run the io_context in a separate thread

    auto connection = std::make_shared<TcpConnection>(io_context2, my_data_handler);

    connection->connect("127.0.0.1", 12345, [connection](const boost::system::error_code& ec) {
        if (!ec) {
            std::cout << "Connected successfully!" << std::endl;
            connection->send("Hello from client!");
            connection->start(); // Start reading
        } else {
            std::cerr << "Failed to connect: " << ec.message() << std::endl;
        }
    });

    std::thread io_thread([&io_context]() { io_context.run(); });
    std::thread io_thread2([&io_context2]() { io_context2.run(); });

    while (true)
    {
        /* code */
    }
    
    return 0;
}
