#ifndef TCP_CONNECTION_H
#define TCP_CONNECTION_H

#include <boost/asio.hpp>
#include <iostream>
#include <string>
#include <functional>
#include "NetworkBase.h"
#include <memory>
#include <vector>
#include "NetworkBase.h"
#include <mutex>

using namespace boost::asio::ip;

class TcpConnection : public std::enable_shared_from_this<TcpConnection>, public NetworkBase
{
public:
    TcpConnection(boost::asio::io_context& io_context)
        : NetworkBase(io_context), _socket(io_context) {}

    TcpConnection(boost::asio::io_context& io_context, 
                  std::function<void(const std::string&, const boost::system::error_code&)> data_handler)
        : NetworkBase(io_context), _socket(io_context),  _data_handler(data_handler) {}

    tcp::socket& socket() {
        return _socket;
    }

    void connect(const std::string& host, uint16_t port, std::function<void(const boost::system::error_code&)> connect_handler) {
        tcp::resolver resolver(_socket.get_executor());
        auto endpoints = resolver.resolve(host, std::to_string(port));
        auto self = shared_from_this();
        async_connect(_socket, endpoints, [self, connect_handler](const boost::system::error_code& ec, const tcp::endpoint&) {
            if (!ec) {
                std::cout << "Successfully connected to " << self->_socket.remote_endpoint() << std::endl;
            } else {
                std::cerr << "Connection failed: " << ec.message() << std::endl;
            }
            connect_handler(ec);
        });
    }
    
    void set_data_handler(std::function<void(const std::string&, const boost::system::error_code&)> data_handler)
    {
        _data_handler = std::move(data_handler);
    }

    void start() {
        read();
    }

    void send(const std::string& message) {
        auto self = shared_from_this();
        boost::asio::async_write(
            _socket,
            boost::asio::buffer(message),
            [self](const boost::system::error_code& ec, std::size_t /*bytes_transferred*/) {
                if (ec) {
                    std::cerr << "Send error: " << ec.message() << std::endl;
                }
            });
    }

    void stop() {
        boost::system::error_code ec;
        _socket.close(ec);
        if (ec) {
            std::cerr << "Error closing socket: " << ec.message() << std::endl;
        }
    }

private:
    void read() {
        auto buffer = std::make_shared<std::vector<char>>(1024); // Dynamically allocate buffer to extend its lifetime
        _socket.async_read_some(boost::asio::buffer(*buffer),
                                [self = shared_from_this(), buffer](const boost::system::error_code& ec, std::size_t bytes_transferred) {
                                    if (!ec) {
                                        std::string data(buffer->data(), bytes_transferred);
                                        if (self->_data_handler) {
                                            self->_data_handler(data, ec); // Pass the received data to the handler
                                        }
                                        self->read(); // Continue reading
                                    } else {
                                        if (self->_data_handler) {
                                            self->_data_handler({}, ec); // Notify the handler of the error
                                        }
                                        if (ec != boost::asio::error::operation_aborted) {
                                            std::cerr << "Read error: " << ec.message() << std::endl;
                                        }
                                    }
                                });
    }

    tcp::socket _socket;
    std::function<void(const std::string&, const boost::system::error_code&)> _data_handler;
};

#endif // TCP_CONNECTION_H
