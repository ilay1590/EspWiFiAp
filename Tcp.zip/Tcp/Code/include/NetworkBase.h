#ifndef NETWORK_BASE_H
#define NETWORK_BASE_H

#include <boost/asio.hpp>
#include <memory>
#include <thread>

class NetworkBase {
public:
    NetworkBase(boost::asio::io_context& io_context)
        : _io_context(io_context)
    {}

    virtual ~NetworkBase() {
        stop();
    }

    virtual void start() = 0;

    virtual void stop() 
    {
        _io_context.stop();

        if (_worker_thread.joinable()) {
            _worker_thread.join();
        }
    }

protected:
    boost::asio::io_context& _io_context;
    std::thread _worker_thread;
};

#endif
