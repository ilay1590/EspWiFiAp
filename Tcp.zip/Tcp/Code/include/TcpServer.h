#ifndef TCP_SERVER_H
#define TCP_SERVER_H

#include "NetworkBase.h"
#include <boost/asio.hpp>
#include <iostream>
#include <memory>
#include <vector>
#include <string>
#include <map>
#include <functional>
#include <thread>
#include <mutex>

using namespace boost::asio::ip;

class TcpServer : public NetworkBase {
public:

class TcpClient {
public:
    TcpClient(const std::shared_ptr<tcp::socket>& socket)
        : _socket(socket) {}

    void disconnect() {
        boost::system::error_code ec;
        _socket->close(ec);
        
        if (ec) {
            std::cerr << "Close failed for client: "<< _socket->remote_endpoint() << ". Error: " << ec.message() << std::endl;
        }
        else
        {
            std::cout << "Disconnected: "  << _socket->remote_endpoint() << std::endl;
        }
    }

    std::shared_ptr<tcp::socket> _socket;
};
  
    TcpServer(boost::asio::io_context& io_context, uint16_t port)
        : NetworkBase(io_context), _acceptor(io_context, {tcp::v4(), port}) {}

    virtual void start() override 
    {
        std::cout << "Server started on port " << _acceptor.local_endpoint().port() << std::endl;
        _worker_thread = std::thread([this]() { _io_context.run(); });
        accept();
    }

    virtual void stop() override {
        std::lock_guard<std::mutex> lock(_clients_mutex);
        for (auto& [endpoint, client] : _clients) {
            client->disconnect();
        }
        _clients.clear();

        _acceptor.close();
        NetworkBase::stop();
        std::cout << "Server stopped." << std::endl;
    }

    void set_data_handler(std::function<void(const std::string&, const tcp::endpoint&)> handler) 
    {
        _data_handler = std::move(handler);
    }

    void disconnect_client(const std::shared_ptr<TcpClient>& client) {
        std::lock_guard<std::mutex> lock(_clients_mutex);
        auto it = _clients.find(client->_socket.get()->remote_endpoint());

        if (it != _clients.end()) {
            it->second->disconnect();
            _clients.erase(it);
            std::cout << "Client " << client->_socket->remote_endpoint() << " disconnected." << std::endl;
        } else {
            std::cerr << "Client " << client->_socket->remote_endpoint() << " not found." << std::endl;
        }
    }

private:
    void accept() {
        auto socket = std::make_shared<tcp::socket>(_io_context);
        _acceptor.async_accept(*socket, [this, socket](const boost::system::error_code& ec) {
            if (!ec) {
                auto endpoint = socket->remote_endpoint();
                std::lock_guard<std::mutex> lock(_clients_mutex);
                
                auto clientEmplace = _clients.emplace(endpoint, std::make_shared<TcpClient>(socket));
                if(!clientEmplace.second)
                {
                    std::cerr << "Accepted client already exist!" << std::endl;
                }
                else
                {
                    std::cout << "New connection from " << endpoint << std::endl;
                    handle_client_connection((*clientEmplace.first).second);
                }

            } else {
                std::cerr << "Accept error: " << ec.message() << std::endl;
            }

            if (_acceptor.is_open()) {
                accept();
            }
        });
    }

    void handle_client_connection(std::shared_ptr<TcpClient>& client) {
        auto buffer = std::make_shared<std::vector<char>>(1024);
        auto& clientSocket = client.get()->_socket; 
        auto endpoint = clientSocket->remote_endpoint();
        clientSocket->async_read_some(
            boost::asio::buffer(*buffer),
            [this, &client, buffer, endpoint](const boost::system::error_code& ec, std::size_t bytes_transferred) {
                if (!ec) {
                    std::string data(buffer->data(), bytes_transferred);
                    std::cout << "Read some" << std::endl;
                    if (_data_handler) {
                        _data_handler(data, endpoint);
                    }

                    handle_client_connection(client); // Continue reading from the client
                } else {
                    std::cerr << "Client error: " << ec.message() << std::endl;
                }
            });
    }

    tcp::acceptor _acceptor;
    std::function<void(const std::string&, const tcp::endpoint&)> _data_handler;
    std::map<tcp::endpoint, std::shared_ptr<TcpClient>> _clients;
    std::mutex _clients_mutex;
};

#endif // TCP_SERVER_H
